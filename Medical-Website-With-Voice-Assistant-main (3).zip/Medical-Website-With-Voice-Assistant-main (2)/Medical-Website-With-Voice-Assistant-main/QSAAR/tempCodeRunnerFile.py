lemmatizer = WordNetLemmatizer()
