import random
import json
import nltk
from nltk.stem import WordNetLemmatizer
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import SGD
import numpy as np
import pickle

# Load data and preprocess
lemmatizer = WordNetLemmatizer()
words = []
classes = []
documents = []
ignore_words = ['?', '!']
data_file = open('AyurBot/data.json').read()
intents = json.loads(data_file)

for intent in intents['intents']:
    for pattern in intent['patterns']:
        w = nltk.word_tokenize(pattern)
        words.extend(w)
        documents.append((w, intent['tag']))
        if intent['tag'] not in classes:
            classes.append(intent['tag'])

words = [lemmatizer.lemmatize(w.lower()) for w in words if w not in ignore_words]
words = sorted(set(words))
classes = sorted(set(classes))

pickle.dump(words, open('AyurBot/texts.pkl', 'wb'))
pickle.dump(classes, open('AyurBot/labels.pkl', 'wb'))

# Create training data
training = []
output_empty = [0] * len(classes)
for doc in documents:
    bag = [1 if w in [lemmatizer.lemmatize(word.lower()) for word in doc[0]] else 0 for w in words]
    output_row = list(output_empty)
    output_row[classes.index(doc[1])] = 1
    training.append([bag, output_row])

# Check for consistency in data
consistent = True
for bag, output_row in training:
    if len(bag) != len(words) or len(output_row) != len(classes):
        print("Inconsistent data detected.")
        consistent = False
        break

if consistent:
    training = np.array(training, dtype=object)
    random.shuffle(training)
    train_x = list(training[:, 0])
    train_y = list(training[:, 1])
    
    
from keras.optimizers import legacy as legacy_optimizers  # Import legacy optimizers

# Create and compile the model
model = Sequential([
    Dense(128, input_shape=(len(train_x[0]),), activation='relu'),
    Dropout(0.5),
    Dense(64, activation='relu'),
    Dropout(0.5),
    Dense(len(train_y[0]), activation='softmax')
])

# Use legacy SGD optimizer
sgd = legacy_optimizers.SGD(learning_rate=0.01, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])

# Fit model
hist = model.fit(np.array(train_x), np.array(train_y), epochs=200, batch_size=5, verbose=1)
model.save('AyurBot/model.h5', hist)
print("Model created successfully!")
